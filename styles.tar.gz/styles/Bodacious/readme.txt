Comes with wallpaper and terminal background. 
This was inspired somewhat by Hazuki's Corvus theme.

The Following fonts are required for this to look as intended:

open-sans (apache 2.0)
http://www.opensans.com/

Lemon Milk (Donationware)
https://www.dafont.com/lemon-milk.font

Magmawave Caps (CC)
http://alphadesigner.com/magmawave-font/


Also looks very nice with BMZ cursor:
https://www.gnome-look.org/p/1158321/

Everything in this file is considered unlicenced
and public domain software.

Enjoy :P
